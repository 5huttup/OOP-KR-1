N = int(input())
x = int(0)
y = int(0)

while y**2 < N:
    if y ** 2 < N:
        print (y**2)
    y = y + 1